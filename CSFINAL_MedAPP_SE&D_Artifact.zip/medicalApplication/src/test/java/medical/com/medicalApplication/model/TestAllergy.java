package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Allergy;

public class TestAllergy {
	
	private Allergy allergy;
	
	@Before
	public void before() {
		this.allergy = new Allergy("Penicilin");
	}
	
	@Test
	public void testSetName() {
		assertTrue(allergy.getName().equals("Penicilin"));
	}
}
