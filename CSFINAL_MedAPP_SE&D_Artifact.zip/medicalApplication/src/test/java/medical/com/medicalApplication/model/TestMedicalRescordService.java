/*
 * 
 * 	Title:	TestMedicalRescordService.java
 * 	Author:	Brandon Rickman <brandon.rickman@snhu.edu>
 * 	Date:	January 30, 2020
 * 
 */


package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.services.DoctorService;
import medical.com.medicalApplication.services.MedicalRecordService;

public class TestMedicalRescordService {
	
	private List<MedicalRecord> medRec;
	private Patient patient;
	
	@Before
	public void setUp() throws Exception {
		// create new objects with params
		MedicalRecordService.getReference().addPatient("Donald Trump", "145A");
		this.patient = MedicalRecordService.getReference().getPatient("145A");
		this.medRec = MedicalRecordService.getReference().getMedicalRecord("145A");
				/*.getPatient().getId().equals("145A");*/
	}
	
	@Test
	public void testAddPatient() {
		// test method from MedicalRescordService
		assertTrue(MedicalRecordService.getReference().addPatient("Michael Pence", "145B"));
	}
	
	/*
	* PROFESSOR: I had an issue figuring out how to set up this Class to call each method.
	* I am aware that in this test under the GETMEDICALRECORD method there is a bug, due to the fact that
	* in the model test for MEDICALRECORD there is a bug. Although I was unable to finish this Class
	* can you guide me on how to finish this Class so I can understand where I went wrong?
	* BRANDON RICKMAN
	*/
	@Test
	public void testGetMedicalRecord() {
		// test method from MedicalRescordService
		assertTrue(MedicalRecordService.getReference().getMedicalRecord(patient.getId()));
		}
	
	@Test
	public void testGetPatient() {
		// test method from MedicalRescordService
	}
	
	@Test
	public void testGetAllPatients() {
		// test method from MedicalRescordService
	}
	
	@Test
	public void testGetPatientsWithAllergies() {
		// test method from MedicalRescordService
	}
}
