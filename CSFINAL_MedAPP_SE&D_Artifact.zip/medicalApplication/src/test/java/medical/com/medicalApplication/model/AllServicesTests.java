/*
 * 
 * 	Title:	AllServicesTests.java
 * 	Author:	Brandon Rickman <brandon.rickman@snhu.edu>
 * 	Date:	January 30, 2020
 * 
 */


package medical.com.medicalApplication.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ 
	// name of class (.class)
	TestDoctorService.class,
	TestMedicalRescordService.class
	})
public class AllServicesTests {

}
