/*
 * 
 * 	Title:	TestDoctorService.java
 * 	Author:	Brandon Rickman <brandon.rickman@snhu.edu>
 * 	Date:	January 30, 2020
 * 
 */


package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.services.DoctorService;

public class TestDoctorService {
	
	@Before
	public void setUp() throws Exception {
		// create new objects with params
		DoctorService.getReference().addDoctor("Bernie Sanders", "2345");
	}
	
	@Test
	public void testGetAllDoctors() {
		// test to get all doctors list
		assertTrue(DoctorService.getReference().getAllDoctors().stream().anyMatch(
				doctor -> doctor.getName().equals("Bernie Sanders") &&
				doctor.getId().equals("2345")
				));
	}
	
	@Test
	public void testAddDoctor() {
		// test to add a new doctor
		assertTrue(DoctorService.getReference().addDoctor("Jane Smith", "1234"));
	}
}
