/*
 * 
 * 	Title:	TestPatientHistory.java
 * 	Author:	Brandon Rickman <brandon.rickman@snhu.edu>
 * 	Date:	January 28, 2020
 * 
 */

package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Treatment;
import medical.com.medicalApplication.model.Patient;


import static org.junit.Assert.*;

public class TestMedicalRecord {
	private MedicalRecord medRecd;
	private Patient patient;
	private PatientHistory history;
	private Treatment treatment;
	private Medication meds1;
	private Medication meds2;
	private Allergy allergy;
	
	@Before
	public void before() {
		this.allergy = new Allergy("None");
		this.meds1 = new Medication("Tylenol", "2020-01-28", "2020-02-02", "50 mg tab");
		this.meds2 = new Medication("Asprin", "2020-01-28", "2020-02-02", "50 mg tab");
		this.treatment = new Treatment("2020-01-28", "Severe headache", "Take one pill every 2 hours as needed.");
		this.patient = new Patient("Donald Trump", "159A");
		
		this.history = new PatientHistory();
		history.addAllergy(allergy);
		history.addMedication(meds1);
		history.addMedication(meds2);
		history.addTreatment(treatment);
		
		this.medRecd = new MedicalRecord(patient);
		}
	
	@Test
	public void testGetPatient() {
		assertTrue(medRecd.getPatient().getName().equals("Donald Trump") &&
				medRecd.getPatient().getId().equals("159A"));
	}
	
	@Test
	public void testGetPatientHistory() {
		assertTrue(medRecd.getHistory().getAllMedications().stream().anyMatch(
				medication -> medication.getName().equals("Tylenol") &&
				medication.getStartDate().equals("2020-01-28") &&
				medication.getEndDate().equals("2020-02-02") &&
				medication.getDose().equals("50 mg tab")
				));
				
		assertTrue(medRecd.getHistory().getAllTreatments().stream().anyMatch(
						treatment -> treatment.getTreatmentDate().equals("2020-01-28") &&
						treatment.getDiagnose().equals("Severe headache") &&
						treatment.getDescription().equals("Take one pill every 2 hours as needed.")
						));
		
		assertTrue(medRecd.getHistory().getAlergies().stream().anyMatch(
				allergy -> allergy.getName().equals("None")
				));
	}

}
