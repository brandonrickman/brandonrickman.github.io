package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Employee;

public class TestEmployee {
	
	private Employee employee;
	
	@Before
	public void before() {
		this.employee = new Employee("Jane Doe", "9876");
	}
	
	@Test
	public void testSetName() {
		assertTrue(employee.getName().equals("Jane Doe"));
	}
	
	@Test
	public void testSetId() {
		assertTrue(employee.getId().equals("9876"));
	}
	
	@Test
	public void testSetPassword() {
		assertTrue(employee.getPassword().equals("Open"));
	}

}
