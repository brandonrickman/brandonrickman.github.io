package medical.com.medicalApplication.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({ 
	TestAllergy.class, 
	TestDoctor.class, 
	TestEmployee.class,
	TestPatient.class,
	TestTreatment.class,
	TestMedication.class,
	TestPatientHistory.class,
	TestMedicalRecord.class
	})
public class AllModelTests {

}