package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Medication;

public class TestMedication {
	
	private Medication meds;
	
	@Before
	public void before() {
		this.meds = new Medication("Fauxcilin", "2019-12-01", "2019-12-10", "25 - 10 mg tabs");
	}
	
	@Test
	public void testSetName() {
		assertTrue(meds.getName().equals("Fauxcilin"));
	}
	
	@Test
	public void testStartDate() {
		assertTrue(meds.getStartDate().equals("2019-12-01"));
	}
	
	@Test
	public void testEndDate() {
		assertTrue(meds.getEndDate().equals("2019-12-10"));
	}
	
	@Test
	public void testDose() {
		assertTrue(meds.getDose().equals("25 - 10 mg tabs"));
	}
}