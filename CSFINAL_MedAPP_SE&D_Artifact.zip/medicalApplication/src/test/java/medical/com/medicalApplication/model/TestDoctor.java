package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import medical.com.medicalApplication.model.Doctor;

public class TestDoctor {
	
	private Doctor doctor;
	
	@Before
	public void before() {
		this.doctor = new Doctor("Smith", "1234");
	}
	
	@Test
	public void testSetName() {
		assertTrue(doctor.getName().equals("Smith"));
	}
	
	@Test
	public void testSetId() {
		assertTrue(doctor.getId().equals("1234"));
	}
	
}
