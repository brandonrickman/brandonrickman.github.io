package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Patient;

public class TestPatient {
	
	private Patient patient;
	
	@Before
	public void before() {
		this.patient = new Patient("Mark Cuban", "123A");
	}
	
	@Test
	public void testSetName() {
		assertTrue(patient.getName().equals("Mark Cuban"));
	}
	
	@Test
	public void testSetId() {
		assertTrue(patient.getId().equals("123A"));
	}
}
