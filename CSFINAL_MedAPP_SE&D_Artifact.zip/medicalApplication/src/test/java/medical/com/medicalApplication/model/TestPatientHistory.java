/*
 * 
 * 	Title:	TestPatientHistory.java
 * 	Author:	Brandon Rickman <brandon.rickman@snhu.edu>
 * 	Date:	January 28, 2020
 * 
 */

package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.Treatment;
import medical.com.medicalApplication.model.Medication;


public class TestPatientHistory {
	private Treatment treatment;
	private Medication medication;
	private Allergy allergy;
	private PatientHistory patientHist;
	
	
	@Before
	public void before(){
		this.patientHist = new PatientHistory();
		
		this.treatment = new Treatment("2020-01-28", "Dry skin", "Apply lotion");
		this.medication = new Medication("Dermicile", "2020-01-28", "2020-02-20", "1 Tube");
		this.allergy = new Allergy("None");
		
		patientHist.addTreatment(treatment);
		patientHist.addTreatment(new Treatment("2020-01-28", "Cold", "Rest"));
		patientHist.addMedication(medication);
		patientHist.addMedication(new Medication("NyQuil", "2020-01-28", "2020-02-20", "10 mL"));
		patientHist.addAllergy(allergy);
		patientHist.addAllergy(new Allergy("N/A"));
	}
	
	
	@Test
	public void testGetAllTreatments() {
		assertTrue(patientHist.getAllTreatments().stream().anyMatch(
				treatments -> treatments.getTreatmentDate().equals("2020-01-28") &&
				treatments.getDiagnose().equals("Dry skin") &&
				treatments.getDescription().equals("Apply lotion")
				));
	}
	
	
	@Test
	public void testGetAllMedications() {
		assertTrue(patientHist.getAllMedications().stream().anyMatch(
				medications -> medications.getName().equals("Dermicile") && 
				medications.getStartDate().equals("2020-01-28") &&
				medications.getEndDate().equals("2020-02-20") &&
				medications.getDose().equals("1 Tube")
				));
	}
	
	
	@Test
	public void testGetAllergies() {
		assertTrue(patientHist.getAlergies().stream().anyMatch(
				allergy -> allergy.getName().equals("None")
				));
	}
}
