package medical.com.medicalApplication.model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import medical.com.medicalApplication.model.Treatment;

public class TestTreatment {
	
	private Treatment treatment;
	
	@Before
	public void before() {
		this.treatment = new Treatment("2019-12-01", "Sinus Infection", "RX for Synthetic Anti-biotics.");
	}
	
	@Test
	public void testSetTreatmentDate() {
		assertTrue(treatment.getTreatmentDate().equals("2019-12-01"));
	}
	
	@Test
	public void testSetDiagnose() {
		assertTrue(treatment.getDiagnose().equals("Sinus Infection"));
	}
	
	@Test
	public void testDescription() {
		assertTrue(treatment.getDescription().equals("RX for Synthetic Anti-biotics."));
	}
}
