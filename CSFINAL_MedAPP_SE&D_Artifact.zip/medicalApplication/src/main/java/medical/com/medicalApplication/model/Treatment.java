package medical.com.medicalApplication.model;
/**
 * 
 * This class represents a treatment model in the system.
 *
 * EDITED: Brandon Rickman <brandon.rickman@snhu.edu>
 * EDITED FOR: CS499 - Computer Science Capstone
 * 
 */
public class Treatment {
	private String treatmentDate;
	private String diagnose;
	private String description;
	private String doctor; // ADD doctor to constructor class

	public Treatment(String doctor, String treatmentDate, String diagnose, String description) {
		super();
		this.doctor = doctor; // ADD doctor to constructor class
		this.treatmentDate = treatmentDate;
		this.diagnose = diagnose;
		this.description = description;
	}

	// ADD funct getDoctor to obtain doctor name
	public String getDoctor() {
		return doctor;
	}
	
	// ADD funct setDoctor to place doctor name into class
	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	
	public String getTreatmentDate() {
		return treatmentDate;
	}

	public void setTreatmentDate(String treatmentDate) {
		this.treatmentDate = treatmentDate;
	}

	public String getDiagnose() {
		return diagnose;
	}

	public void setDiagnose(String diagnose) {
		this.diagnose = diagnose;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	// EDIT: return string for class
	@Override
	public String toString() {
		return "Treatment: " + " Date: "+ treatmentDate + ", Doctor: " + doctor + ", Diagnosis: " + diagnose + ", Notes: " + description;
		// STRING: "Treatment: Date: [date], Doctor: [doctorname], Diagnosis: [diagnosis], Notes: [description]"
	}

}
